#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 22 18:45:28 2023

@author: nfamartins
"""

def subtracao(a,b):
    return a-b
